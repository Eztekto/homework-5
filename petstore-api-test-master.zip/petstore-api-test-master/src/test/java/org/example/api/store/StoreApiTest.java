package org.example.api.store;

import org.testng.annotations.Test;

public class StoreApiTest {
    @Test
    public void placeOrderTest() {
        // todo: офрмить заказ на питомца
        // todo: найти оформленный заказ
    }

    @Test
    public void deleteOrderTest() {
        // todo: удалить заказ
        // todo: проверить удаление заказа
    }
}
